""""""
""" print 1 to 10"""
# n = 1
# while n <= 10:
#     print(n)
#     n += 1

"""print 10 to 1"""

# n = 10
# while n > 0:
#     print(n)
#     n -= 1

""" print -1 to -10 """

# n = -1
# while n >= -10:
#     print(n)
#     n -= 1

""" print -10 to -1 """
# n = -10
#
# while n < 0:
#     print(n)
#     n += 1

""" print even numbers """

# n = 1
# while n <= 50:
#     if n % 2 == 0:
#         print(n)
#     n += 1

# n = 1
# while n <= 50:
#     print(n)
#     n += 2

""" print each character in a string """

string = "python"
i = 0

while i < len(string):
    print(string[i])
    i += 1
















