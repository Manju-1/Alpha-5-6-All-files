""" WAP to check if the given input number is even"""

# number = int(input("enter a number: "))
# print(type(number))
#
# if number % 2 == 0:
#     print("number is even")


""" WAP to check if the given character is in lowercase """

# char = input("enter a character:")
#
# if "a" <= char <= "z":
#     print(f"{char} is lowercase character")
#
# if char.islower():
#     print(f"{char} is lowercase character")

""" WAP to check if the element in present in collection """

list_ = ["python", "java", "linux", "ruby", "nodejs"]
element = "c++"

if element in list_:
    print(f"{element} is a member of list_")


















