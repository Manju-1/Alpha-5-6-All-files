from collections import defaultdict

""" Write a program to get the indexes of each item in the below list
names = ['apple', 'google', 'apple', 'yahoo', 'yahoo', 'google', 'gmail', 'gmail', 'gmail']
output should be -  {'apple': [0, 2], 'google': [1, 5], 'yahoo': [3, 4], 'gmail': [6, 7, 8]}
"""

names = ['apple', 'google', 'apple', 'yahoo', 'yahoo', 'google', 'gmail', 'gmail', 'gmail']
d = defaultdict(list)
for index, item in enumerate(names):
    d[item] += [index]

# print(d)

""" Reverse the values in the dictionary if the value is of type String"""
d = {'a': 'hello', 'b': 100, 'c': 10.1, 'd': 'world'}

for key, value in d.items():
    if isinstance(value, str):
        d[key] = value[::-1]
    else:
        d[key] = value
# print(d)

"""Write a program to get all the duplicate items and the number of times the item is repeated in the list."""
names = ['apple', 'google', 'apple', 'yahoo', 'yahoo', 'facebook', 'apple', 'gmail', 'gmail', 'gmail', 'gmail']

d = {}
for item in names:
    if names.count(item) > 1:
        d[item] = names.count(item)
# print(d)

"""Creating Dictionary of city and population pairs using Dict Comprehension"""
cities = ['Tokyo',  'Delhi',  'Shanghai',   'Sao Paulo',  'Mumbai']
population = ['38,001,000',  '25,703,168',  '23,740,778',   '21,066,245',  '21,042,538']

c = zip(cities, population)
# print(dict(c))
# or
d = {key: value for key, value in c}
# print(d)


""" Write a program to flip keys and values. """
d = {'a': 'hello', 'b': 100, 'c': 10.1, 'd': 'world'}
res = {}
for key, value in d.items():
    res[value] = key
# print(res)

""" Group even and odd  index values with comprehension"""
l = [1, 2, 2, 3, 4, 4, 5, 5, 5, 6, 7, 7, 8, 8, 8, 88, 99, 100]

even = [index for index, item in enumerate(l) if item % 2 == 0]
odd = [index for index, item in enumerate(l) if item % 2 != 0]

d = {item1: item2 for item1, item2 in zip(("even", "odd"), (even, odd))}
# print(d)

""" """








