def greet():
    yield "hello world"
    yield "hai"
    yield "hello"


msg = greet()
# print(list(msg))

# for item in msg:
#     print(item)


l = [1, 2, 3, 4, 5]
# res = [1, 4, 9, 16, 25]

# res = [item ** 2 for item in l]
# print(res)

def squares():
    for item in l:
        yield item ** 2


res = (item ** 2 for item in l)
# print(list(res))

"""
res 
| 1, 4, 9, 16, 25 |

"""

# for item in res:
#     print(item)


# print(next(res))    # 1
# print(next(res))    # 4
# print(next(res))    # 9
# print(next(res))    # 16
# print(next(res))    # 25
#
# print(next(res))    # stop Iteration


# write a generator function to yield even numbers in the range 1 - 50

def evens():
    for item in range(1, 51):
        if item % 2 == 0:
            yield item


# even_num = evens()
# print(even_num)     # generator object address
# print(list(even_num))


# generator expression

evens_ = (item for item in range(1, 51) if item % 2 == 0)
print(evens_)    # generator object address
print(list(evens_))


# write a generator function to yield the names starting with vowels in the given list

names = ["john", "eve", "bob", "emma", "ana"]

def vowels(iterable):
    for item in iterable:
        if item[0].lower() in "aeiou":
            yield item


v = vowels(names)
print(list(v))


# gen experession

vowels = (item for item in names if item[0].lower() in "aeiou")
print(list(vowels))

# write a generator function and expression to yield length of each line in a file only if the line is not empty

filepath = r""

def line_length():
    with open(filepath) as file:
        for line in file:
            if line.strip():
                yield line

# lines = line_length()
# print(list(res))























