"""
1. function should be nested function
2. outer function must accept one parameter
3. the parameter in out function should be called inside
nested function
4. outer function must return inner function's address
"""
def spam(func):
    def wrapper(*args, **kwargs):
        print("The no of arguments are:",len(args) + len(kwargs))
        func(*args, **kwargs)
    return wrapper

# @spam       # add = spam(add)
# def add(a, b):
#     print(a + b)
# add(1, 2)
#
# @spam       #reverse_ = spam(reverse_)
# def reverse_(string):
#     print(string[::-1])


# reverse_("hai")

# log decorator
def log(func):
    def wrapper(*args, **kwargs):
        print("In decorator function")
        func(*args, **kwargs)
    return wrapper


@log        # display = log(display)
def display():
    print("In display")
# display()

# delay decorator
import time

def delay(func):
    def wrapper(*args, **kwargs):
        time.sleep(2)
        return func(*args, **kwargs)
    return wrapper

@delay
def display():
    return "In display"
# print(display())


# reverse decorator
def reverse_(func):
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        return res[::-1]
    return wrapper

@reverse_
def spam(string):
    return string


# print(spam("hello"))

## executing a function for n times

def outer(n):
    def repeat_(func):
        def wrapper(*args, **kwargs):
            for i in range(n):
                func(*args, **kwargs)
        return wrapper

    return repeat_

@outer(3)       # @repeat_
def add(a, b):
    print(a + b)

# add(1, 2)

@outer(2)
def sub(a, b):
    print(a - b)

# sub(10, 4)

# delay for n seconds

def outer_(n):
    def delay(func):
        def wrapper(*args, **kwargs):
            time.sleep(n)
            func(*args, **kwargs)
        return wrapper
    return delay


@outer_(3)
def add(a, b):
    print(a + b)

# add(1, 2)

@outer_(2)
def sub(a, b):
    print(a - b)

# sub(10,8)


# time of execution of a function


def outer_(n):
    def delay(func):
        def wrapper(*args, **kwargs):
            start = time.time()
            time.sleep(n)
            func(*args, **kwargs)
            end = time.time()
            print(f"time of execution is: {end - start}")
        return wrapper
    return delay

@outer_(2)
def sub(a, b):
    print(f"output of a-b is : {a - b}")

sub(1, 2)

















