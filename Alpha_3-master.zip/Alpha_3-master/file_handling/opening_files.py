file = open(r"C:\Users\Vidya\PycharmProjects\Alpha_3\files_directory\txt_log_files\sample.txt")
print(file)

import os

os.popen(r"C:\Users\Vidya\PycharmProjects\Alpha_3\files_directory\txt_log_files\sample.txt")
