import csv

with open("example.csv", "w") as csv_:
    write_obj = csv.writer(csv_)
    write_obj.writerow(["x", "y", "z"])
    write_obj.writerows([(1, 2, 3), (5, 6, 7), (8, 7, 9)])


with open("example.csv", "w") as csv_writer:
    dictwriter_obj = csv.DictWriter(csv_writer, ["x", "y", "z"])
    dictwriter_obj.writeheader()
    dictwriter_obj.writerow({"x": 10, "y": 20, "z": 30})
