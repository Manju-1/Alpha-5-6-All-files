import pickle

# a = "hai"

# b = pickle.dumps(a)
# print(b)
# print(type(b))
#
# c = pickle.loads(b)
# print(c)



data = "hello"

# with open("example.pkl", "wb") as file:
#     pickle.dump(data, file)


with open("example.pkl", "rb") as file:
    res = pickle.load(file)
    print(res)
