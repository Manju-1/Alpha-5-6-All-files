# dump(), dumps()

import json
a = {"hai": 3, "hello": 4}

b = json.dumps(a)
print(b)
print(type(b))      # str

c = json.loads(b)
print(type(c))      # dict



# a = True
# print(type(a))
#
# b = json.dumps(a)
# print(b)
# print(type(b))




a = {"a": 1, "b": 2, "c": 3}

with open("sample.json", "a") as file:
    json.dump(a, file)

with open("sample.json") as file:
    print(json.load(file))







