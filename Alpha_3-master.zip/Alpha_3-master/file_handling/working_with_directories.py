import os

print(os.getcwd())
os.chdir(r"C:\Users\Vidya\PycharmProjects\Alpha_3\files_directory\txt_log_files")

print(os.getcwd())
# os.mkdir("directory1")
os.rmdir("directory1")
