import keyword

# print(keyword.iskeyword("While"))


a = 10
b = 20

# print(a, end=" ")
# print(b)

# print(a, b, sep=",")

# print(a, b, end=",")

# value = input("enter a value:")
#
# print("value is", value)
# a = "ram"
# b = 10

# print("my name is", a, end=" ")
# print("I am", b, "years old")

# print("my name is", a, sep="$$", end=" ")
# print("I am", b, "years old", sep="$$")

# print("my name is", a, end="$$")
# print("I am", b, "years old")



