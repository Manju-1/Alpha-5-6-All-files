# default values of individual datatypes

"""
integer - 0/ int()
float - 0.0/float()
complex - 0j/0+0j/complex()
boolean - False
"""

# strings

s = 'hello world "welcome!!!!" '
s1 = "hello world"
s2 = '''helloo world'''
s3 = """hello world"""

# default values

#s = '', "", '''''', """"""
s1 = str()


# length 
len(s)

name = input("enter the name:")
string = f"My name is {name}"

s = "My name is %s"%name








