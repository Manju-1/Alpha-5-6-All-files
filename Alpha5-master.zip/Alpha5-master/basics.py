name = input("enter the name:")
age = input("enter the age:")

print("My name is", name, sep="%", end=" ** ")
print("My age is", age)

# creating a constant 
NAME = "Ram"

