# creating a list
l = [1, 2, 3, 4, 5]
l = [1, 1.2, "hai", "hello", [10, 20]]
l = list([1, 2, 3])
print(l)

# default values
l = []
l = list()

# merging two lists

l1 = [1, 2, 3]
l2 = ["a", "b", "c"]

# print(l1 + l2)
# print([*l1, *l2])

# Activity
names = ['apple', 'google', 'yahoo', 'amazon', 'facebook', 'instagram', 'microsoft']
# print(names[2][3])
# s = names[2]    # yahoo
# s[3]
# print(names[-2:3])

# names[:2] = ["unknown", "unknown"]
# print(names[:2])
# print(names)
names[:2] = ["unknown", "unknown", "unknown"]
# print(names)




