s = "abc"

print(list(s))
print(tuple(s))
print(set(s))
# print(dict(s))  # valueError

s1 = "10"
print(int(s1))
print(float(s1))
print(complex(s1))
print(bool(s1))

print()
print()
l = [1, 2, 3]

print(str(l))
print(tuple(l))
print(set(l))
# print(dict(l))  # valueError

l1 = [[1, 2], [3, 4], [5, 6]]
print(dict(l1))

l1 = [(1, 2), (3, 4), [5, 6]]
print(dict(l1))

l1 = ["ab", "12", "cd"]
print(dict(l1))

print()
print()

s = {1, 2, 3}

print(str(s))
print(list(s))
print(tuple(s))

print()
print()

d1 = {"a": 1, "b": 2}
print(str(d1))
print(list(d1))
print(tuple(d1))
print(set(d1))


