# boundaries

s1 = 'hello'
s2 = "hello this is Ram's car"
s3 = '''hello
hello world
python'''
s4 = """hello"""

# default values
s = ""
s6 = str()


# length of string
s = "hello world"
# print(len(s))

# Raw strings

s = r"py\tho\n selenium"
# print(s)

# indexing a string
string = "hello world"
# print(string[0])
# print(string[-1])


#
name = "Sita"
greet = f"hello {name}"
# print(greet)

s = "The value of pi is %f "%(3.141592)
# print(s)
s = "The value of pi is %0.2f "%(3.141592)
# print(s)

string = "Hi Welcome to python"

print(string[::2])
print(string[::-2])
print(string[::-1])

print("youtube.txt"[-3:])
print("youtube.txt"[:-4])

url = "https://google.com"
print(url[:5])
print(url[8:14])



























