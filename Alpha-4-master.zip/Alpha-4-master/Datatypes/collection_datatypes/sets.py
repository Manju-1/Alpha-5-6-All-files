# creating sets

s = {1, 2, 3, 4, 5}
s = set({1, 2, 3, 4})
# print(s)

s1 = {1, 2, 3, (1, 2, 3)}
# print(s1)

# default value
s = set()
print(type(s))