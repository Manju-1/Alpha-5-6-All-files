# print("hello", end=" ")
# print("hai")


# print("hai", "hello", "python", sep="_")

# a = input("enter the value of a: ")
# print(a)

""" Activity """

# a = "Ram"
# b = 10
# print("My name is ", a, sep="&&", end=" ")
# print("I am", b, "years old", sep="&&")

# print(sep="@", "hai", "hello")  # SyntaxError


s = "so123p56ltd78"
i = 0
while i < len(s):
    j = num = []
    z = 0
    while i < len(s):
        if s[i].isdigit():
            j.append(s[i])
            i += 1

        else:
            i += 1
            break
    print(j)












