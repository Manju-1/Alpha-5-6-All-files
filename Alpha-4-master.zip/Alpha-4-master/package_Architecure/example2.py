a = 10
b = 20

print("example2.py is referred to as:", __name__)
def display():
    print(a, b)

# setting the priority
if __name__ == "__main__":
    display()

