x = 20
y = 30
print(x, y)
from package_Architecure.example2 import display
display()
def display():
    print("hi")