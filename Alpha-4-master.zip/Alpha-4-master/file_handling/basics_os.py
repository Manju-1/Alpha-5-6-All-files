import os

# current working directory
print(os.getcwd())

# path = r"C:\Users\Vidyashree M C\PycharmProjects\Alpha4\Datatypes"
# changing the directory
# os.chdir(path)
# print(os.getcwd())

# creating folder
# os.mkdir("sample")

# delete folder
# os.rmdir("sample")

# path = r"C:\Users\Vidyashree M C\PycharmProjects\Alpha4"

# os.chdir(path)
# print(os.listdir(path))


# creating a file

# os.mkdir("overriding_class_variable.py")
# os.rmdir("overriding_class_variable.py")

# removing a file
# os.remove("overriding_class_variable.py")

path = r"C:\Users\Vidyashree M C\PycharmProjects\Alpha4\files\sample.txt"

os.popen(path)







